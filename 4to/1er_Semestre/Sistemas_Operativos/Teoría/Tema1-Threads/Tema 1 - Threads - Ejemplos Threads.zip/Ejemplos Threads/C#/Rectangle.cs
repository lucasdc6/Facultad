/*Authour: IMW
 *Date: 22/10/2002
 **/
using System;
using System.Drawing;
using System.Threading;

namespace ThreadTester
{
	public class Rectangle : Shapes
	{
		public Rectangle(int x,int y,int w,int h, Color c,Form1 f,int spd)
		{ xVal = x; yVal = y; color = c; width = w; height = h;	frm1 = f; speed = spd;}
				
		public override void  paint(Graphics g)
		{	
			try
			{
				Thread.Sleep(speed);
				g.DrawRectangle(new System.Drawing.Pen(frm1.BackColor),xVal,yVal,width,height);
				lock(typeof(Thread))
				{	xVal = xVal+ base.directionX; 
					yVal = yVal+ base.directionY;
					base.CheckCoordinates();
				}
				g.DrawRectangle(new System.Drawing.Pen(color),xVal,yVal,width,height); 
			}
			catch(Exception e)
			{}
			
		}
	}
}
		


