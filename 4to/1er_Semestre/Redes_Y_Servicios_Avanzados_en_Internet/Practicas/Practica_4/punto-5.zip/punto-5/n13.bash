ifconfig eth0 10.0.6.2/24
ifconfig eth1 10.0.4.1/24
ifconfig eth2 10.0.11.2/24
route add default gw 10.0.11.1
