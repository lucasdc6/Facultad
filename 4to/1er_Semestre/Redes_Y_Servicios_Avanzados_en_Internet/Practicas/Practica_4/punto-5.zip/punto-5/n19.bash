ifconfig eth0 200.0.1.2/24
route add default gw 200.0.1.1
