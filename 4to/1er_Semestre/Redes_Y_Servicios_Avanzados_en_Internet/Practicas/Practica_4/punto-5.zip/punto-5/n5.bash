ifconfig eth0 10.0.2.2/24
ifconfig eth1 10.0.7.1/24
ifconfig eth2 10.0.10.1/24
route add default gw 10.0.10.2
