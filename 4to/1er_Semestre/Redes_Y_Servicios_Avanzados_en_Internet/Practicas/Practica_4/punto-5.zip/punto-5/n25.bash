ifconfig eth0 10.0.8.20/24
route add default gw 10.0.8.1
