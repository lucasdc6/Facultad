ifconfig eth2 10.0.6.1/24
ifconfig eth0 10.0.5.2/24
route add default gw 10.0.5.1
