ifconfig eth0 10.0.14.10/24
route add default gw 10.0.14.1
