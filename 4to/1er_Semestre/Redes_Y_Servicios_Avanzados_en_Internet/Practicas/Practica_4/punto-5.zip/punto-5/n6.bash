ifconfig eth0 200.0.1.1/24
ifconfig eth1 200.0.0.2/24

