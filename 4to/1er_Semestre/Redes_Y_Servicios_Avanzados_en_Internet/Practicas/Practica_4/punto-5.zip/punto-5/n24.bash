ifconfig eth0 10.0.17.20/24
route add default gw 10.0.17.1
