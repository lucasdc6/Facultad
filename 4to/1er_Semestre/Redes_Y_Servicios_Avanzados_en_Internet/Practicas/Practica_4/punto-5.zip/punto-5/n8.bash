ifconfig eth0 10.0.10.2/24
ifconfig eth1 10.0.13.2/24
route add default gw 10.0.13.1
