ifconfig eth1 10.0.13.1/24
ifconfig eth0 200.0.0.1/24
route add default gw 200.0.0.2
