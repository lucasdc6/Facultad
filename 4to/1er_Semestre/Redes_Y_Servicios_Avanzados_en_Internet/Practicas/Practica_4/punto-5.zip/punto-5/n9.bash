ifconfig eth0 10.0.9.2/24
ifconfig eth2 10.0.15.1/24
route add default gw 10.0.9.1
