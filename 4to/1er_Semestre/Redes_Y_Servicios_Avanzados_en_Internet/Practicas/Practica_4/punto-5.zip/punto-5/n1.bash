ifconfig eth0 10.0.0.1/24
ifconfig eth1 10.0.1.1/24
route add default gw 10.0.1.2
