ifconfig eth4 10.0.18.2/24
ifconfig eth0 10.0.1.2/24
ifconfig eth1 10.0.2.1/24
ifconfig eth2 10.0.5.1/24
ifconfig eth3 10.0.14.1/24
route add default gw 10.0.2.2
