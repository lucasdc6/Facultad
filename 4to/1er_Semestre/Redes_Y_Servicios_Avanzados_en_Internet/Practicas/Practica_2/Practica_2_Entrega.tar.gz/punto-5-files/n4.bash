ifconfig eth0 10.0.3.2/24
ifconfig eth1 10.0.4.1/24
ifconfig eth2 10.0.5.1/24

