ifconfig eth0 10.0.0.2/24
ifconfig eth1 10.0.1.1/24
ifconfig eth2 10.0.5.2/24

