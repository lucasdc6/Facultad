ifconfig eth0 10.0.2.2/24
ifconfig eth1 10.0.3.1/24

