ifconfig eth2 10.0.3.12/24
ifconfig eth0 10.0.2.3/24
ifconfig eth1 10.0.2.4/24

