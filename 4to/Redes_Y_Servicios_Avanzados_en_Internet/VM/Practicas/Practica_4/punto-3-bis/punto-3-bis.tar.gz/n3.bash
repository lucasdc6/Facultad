ifconfig eth0 10.0.1.2/24
ifconfig eth1 10.0.2.1/24

