ifconfig eth0 10.0.2.2/24
ifconfig eth1 10.0.3.1/24
ifconfig eth2 10.0.5.1/24

