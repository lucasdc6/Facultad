ifconfig eth0 10.0.7.2/24
ifconfig eth1 10.0.8.1/24

