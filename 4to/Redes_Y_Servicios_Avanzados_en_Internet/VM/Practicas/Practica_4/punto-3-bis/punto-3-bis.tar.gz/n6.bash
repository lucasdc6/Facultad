ifconfig eth0 10.0.5.2/24
ifconfig eth1 192.168.1.1/24

