ifconfig eth0 10.0.6.1/24

