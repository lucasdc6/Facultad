ifconfig eth0 192.168.1.2/24
ifconfig eth1 10.0.6.2/24

